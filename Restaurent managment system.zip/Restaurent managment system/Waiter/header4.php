<?php  
 $connect = mysqli_connect("localhost", "root", "", "admin");  
 $query = "SELECT * FROM registe4";  
 $result1 = mysqli_query($connect, $query);  
 while($row = mysqli_fetch_array($result1) )  
 {  
    $y=$row['id'];

     $x=$row['username'];




 }  
 ?> 
<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/header4.css">
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
     <section class="x">
     <div class="y1"><a href="afterindex3.php"id="xc"><img src="../images/logo1.png" width="140px"height="140px" class="x1"></a>
    
    <p class="x2">Burgar Baba Restaurant<br></p>
</div>
     <ul class="p">
         <li class="x4" id="c1"><a href="afterindex3.php"><i class="fa fa-home" style='font-size:24px'></i> Home</a></li>
       
         <li class="x4" id="c2"><a href="mail4.php"><i class="fa fa-fw fa-envelope" style='font-size:24px'></i>  Contact </a></li>
      
       <li class="x4" id="c3"><a href="menu4.php"><i class="fa fa-bars" aria-hidden="true" style='font-size:24px'></i> Menu List</a></li>
     
       <li class="x4" id="c4"><a href="about4.php"> <i class="fa fa-globe"></i> About</a></li>
      
    
       <li class="x4" id="c6"><a href="orderlist.php"><i class="fa fa-shopping-cart" style="font-size:24px"></i> Order List</a></li>
       
       
       <li class="x4"><a href="delet5.php?dele=<?php echo $y; ?>"><i class="fas fa-sign-out-alt" style='font-size:24px'></i>Sign Out</a>  
          
           
            
           
      
      </li>

      </ul>

        

      

       
     </section>
     
</body>
</html>   