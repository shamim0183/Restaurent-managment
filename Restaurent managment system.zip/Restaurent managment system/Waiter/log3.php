<?php	
	session_start();
	$mysqli = new mysqli('localhost', 'root', '', 'admin');
	
	if($mysqli === false){
		die("ERROR: Could not connect. " . $mysqli->connect_error);
	}
	
	$username = $password =$waiterid ="";
	$username_err = $password_err = $waiterid_err="";
	// Processing form data when form is submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	
		// Check if username is empty
		if(empty(trim($_POST["username"]))){
			$username_err = "Please enter username.";
		} else{
			$username = trim($_POST["username"]);
		}
		// Check if password is empty
		if(empty(trim($_POST["passwordd"]))){
			$password_err = "Please enter your password.";
		} else{
      $password = trim($_POST["passwordd"]);
		}

		if(empty(trim($_POST["waiterid"]))){
			$waiterid_err = "Please enter waiter id.";
		} else{
			$waiterid = trim($_POST["waiterid"]);
		}
		if(empty($username_err) && empty($password_err) && empty($waiterid_err)){
		$sql="SELECT * FROM register3 WHERE username='$username' AND passwordd='$password' AND waiterid='$waiterid' LIMIT 1";
		$sql1 = "INSERT INTO registe4 (username,passwordd,waiterid) VALUES ('$username','$password','$waiterid')";
			if($result = $mysqli->query($sql) )
			{
				if($result->num_rows > 0)
				{
					if($result1 = $mysqli->query($sql1))
                    {
						echo '<script>alert("Waiter Login Successfully")</script>';
						echo '<script>window.location="afterindex3.php"</script>';
						$_SESSION[user]=$username;
					}
					
				}
				else
				{
					echo '<script>alert("Username Or Password is wrong")</script>';
					echo '<script>window.location="login3.php"</script>';
				}
			}
		}
	}
?>