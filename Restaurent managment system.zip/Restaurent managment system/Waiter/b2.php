<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/body2.css">

</head>

<body>
<section class="cv">
<div id="slider">
<figure>
<img src="../images/page2_img1.jpg" alt>
<img src="../images/page2_img2.jpg" alt>
<img src="../images/page2_img3.jpg" alt>
<img src="../images/page2_img4.jpg" alt>
<img src="../images/page2_img5.jpg" alt>
</figure>
</div>
<section>
</body>
</html>   



