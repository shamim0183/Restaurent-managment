<?php
   
    
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $mailName = $_POST['mailName'];
        $mailEmail = $_POST['mailEmail'];
        $mailMessage = $_POST['mailMessage'];

        $formcontent="From: $mailName \nSender Email: $mailEmail \nMessage: $mailMessage";
        $recipient = "tipusultan9t7a@gmail.com";
        $subject = "Contact Form";
        $mailheader = "From: $mailEmail \r\n" . "CC: tipusultan9t7a@gmail.com";

        mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
        
    }
?>
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BBR</title>
        <link rel="icon" type="image/ico" href="images/logo1.png" />
        <link rel="stylesheet" href="styles/body1.css">
    </head>
    <body>
<section>
             <h2 class="tes"></h2>
        </section>
   
        <section>
             <h2 class="tes1">
            
          
                        <form id="registrationForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <h4>Restaurant Ower Feedback From</h4>
                            <h1>Write A Message</h1>
                            <p>*All fields are required.</p>
                            <div>
                                <label for="mailName">Name :</label>
                                <input type="text" id="mailName" name="mailName" placeholder="Enter Your Name" oninvalid="InvalidMsg10(this);"  oninput="InvalidMsg10(this);" required>
                            </div>
                            <div>
                            <br><br>

                                <label for="mailEmail">Email :</label>
                                <input type="email" id="mailEmail" name="mailEmail" placeholder="Enter Your Email" oninvalid="InvalidMsg11(this);"  oninput="InvalidMsg11(this);" required>
                                
                            </div>
                            <div>
                                <br><br>
                                <label for="mailMessage">Message :</label>
                                <textarea id="mailMessage" name="mailMessage" placeholder="Enter Your  Message" oninvalid="InvalidMsg12(this);"  oninput="InvalidMsg12(this);" required></textarea>
                                <br><br>
                            </div>
                            <div>
                                <input type="reset" name="reset" id="reset" value="Clear">
                                <input type="submit" name="send" id="send" value="Send">
                            </div>
                        </form>
                   
                 
                
               
          
</h2>
        </section>
        </body>
</html>