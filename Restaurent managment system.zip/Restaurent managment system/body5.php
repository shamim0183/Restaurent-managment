
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BBR</title>
        <link rel="icon" type="image/ico" href="images/logo1.png" />
        <link rel="stylesheet" href="styles/body5.css">
        <link href="https://fonts.googleapis.com/css2?family=Dosis:wght@200&family=Open+Sans+Condensed:ital,wght@1,300&family=Ultra&display=swap" rel="stylesheet">

        <link href="https://fonts.googleapis.com/css2?family=Ultra&display=swap" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script>
               function previewFile(input){
               var file = $("input[type=file]").get(0).files[0];
              if(file){
                       var reader = new FileReader();
                       reader.onload = function(){
                       $("#previewImg").attr("src", reader.result);
                       }
                      reader.readAsDataURL(file);
                      {
                        var x = document.getElementById("myInput").value;
                        document.getElementById("demo").innerHTML = x;
                      }
                    }
              }
        </script>
    </head>
    <body>       
    <section>
             <h2 class="tes"></h2>
        </section>
   
        <section>
             <h2 class="tes1">  
                            <form id="registrationForm" action="wish.php" method="post" enctype="multipart/form-data">
                            <h4>For any kind of Food Wish, please</h4>
                            <h1>Fill Food Wish Form</h1>
                            <p>*All fields are required.</p>
                            <div>
                                <label for="Name" id="label1">Customer Name :</label>
                                <input type="text" id="i1" placeholder="Enter Customer Name" name="Customer_Name" oninvalid="InvalidMsg90(this);"  oninput="InvalidMsg90(this);" required>
                            </div>
                            <div>
                            <br><br>

                                <label for="userid" id="label1">Customer ID :</label>
                                <input type="text" id="i2" placeholder="Enter Customer Id" name="Customer_Id" oninvalid="InvalidMsg91(this);"  oninput="InvalidMsg91(this);" required>
                            </div>
                            <div>
                            <br><br>

                                <label for="mailEmail" id="label1">Customer Email :</label>
                                <input type="email" id="i3" placeholder="Enter Customer Email" name="Customer_Email" oninvalid="InvalidMsg92(this);"  oninput="InvalidMsg92(this);" required>

                            </div>
                            <div>
                            <br><br>

                                <label for="WishFoodName" id="label1">Wish Food Name :</label>
                                <input type="text" id="i4" placeholder="Enter Wish Food Name" name="Wish_Food_Name" oninvalid="InvalidMsg93(this);"  oninput="InvalidMsg93(this);" required>

                            </div>
                            <div>
                            <br><br>

                                <label for="foodcodeno" id="label1">Food Code No :</label>
                                <input type="text" id="i5" placeholder="Enter Food Code No" name="Food_Code_No" oninvalid="InvalidMsg94(this);"  oninput="InvalidMsg94(this);" required>

                            </div>
                            <div>
                            <br><br>

                                <label for="foodcodeno" id="label1">Table Number :</label>
                                <input type="text" id="i5" placeholder="Enter Table Number" name="Table_Number" oninvalid="InvalidMsg95(this);"  oninput="InvalidMsg94(this);" required>
                                <br><br>

                            </div>
                            <div>

                                <input type="hidden" id="i6" name="status" value="place">

                            </div>
                            <div>
                                <input type="reset"  id="reset" value="Clear">
                                <input type="submit" name="Submit" id="Submit" value="Wish">
                             
<br><br>
                            </div>
                            
                        </form>       
                        </h2>
        </section>   
  </body>
</html>