  


<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod3.css">	
    
	</head>
	<body>
    <section class="cv">

		
			
		
			
			
			
			<h3 style="color:white;margin-left:20px"><br>Wish List Details <a style="color:white;margin-left:850px;text-decoration:none;background-color:orange;padding:3px;border-radius:5px;" href="../test2.php"><i class="fa fa-file-pdf-o" style="font-size:24px;color:white"></i> INVOICE PDF</a></h3>
			<div class="table-responsive" style="width:95%;margin-left:15px">
				<table class="table">
					<tr>
						<th  id="vb">Customer Name</th>
                        <th  id="vb">Customer Id</th>
                        <th  id="vb">Email</th>
                        <th  id="vb">Wish Food Name</th>
                        <th  id="vb">Table Number</th>
             <th  id="vb">Status</th>
             <th  id="vb">Total</th>

            
             <th  id="vb">Action</th>
          

					</tr>
                    <?php 

                       $mysqli = new mysqli('localhost', 'root', '', 'admin');
 
                           if($mysqli === false){
                           die("ERROR: Could not connect. " . $mysqli->connect_error);
                         }


$query1 = "SELECT * FROM wish where wish.status='processing'";

$total5 = 0;

if ($result = $mysqli->query($query1)) {

    /* fetch associative array */
    while ($row = $result->fetch_assoc()) {
        $id=$row['id'];
        $Customer_Name = $row["Customer_Name"];
        $Customer_Id = $row["Customer_Id"];
        $Customer_Email = $row["Customer_Email"];
        $Wish_Food_Name = $row["Wish_Food_Name"];
        $Table_Number = $row["Table_Number"];
        $status = $row["status"];

        $query = "SELECT order1.price,order1.price_tax,order1.food_name FROM order1 where order1.food_name='$Wish_Food_Name'";
        
        if ($result1 = $mysqli->query($query)) {
        
          /* fetch associative array */
          while ($row2 = $result1->fetch_assoc()) {
              $total=$row2['price'];
              $price_tax=$row2['price_tax'];

              $total5 = $total;
        
          }
          $total6= $total5+($total5*$price_tax)/100;

          /* free result set */
          $result1->free();
        }

       

        echo '<tr> 
        <td id="vb1" style="text-align:center">'.$Customer_Name.'</td> 
        <td id="vb1" style="text-align:center">'.$Customer_Id.'</td> 
        <td id="vb1" style="text-align:center">'.$Customer_Email.'</td> 
        <td id="vb1" style="text-align:center">'.$Wish_Food_Name.'</td> 
        <td id="vb1" style="text-align:center">'.$Table_Number.'</td> 
        <td id="vb1" style="text-align:center">'.$status.'</td> 

        <td id="vb1" style="text-align:center">'.$total6.'</td> 

        <td id="vb1"><a href="edit22.php?edit='.$id.'" style="margin-left:20px;"><i class="fa fa-edit" style="font-size:24px"></i>	</a></td>
       

        </tr>';
    }

    /* free result set */
    $result->free();
}
?>
				 	
					
					
					
						
				</table>
                
               <br>
			</div>
		
    </section>
    
	</body>
</html>



