<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="images/logo1.png" />
    <link rel="stylesheet" href="styles/header.css">
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
     <section class="x">
     <div class="y1"><a href="index.php"id="xc"><img src="images/logo1.png" width="140px"height="140px" class="x1"></a>
    
     <p class="x2">Burgar Baba Restaurant<br></p>

    </div>
     <ul class="p">
         <li class="x4" id="f11"><a href="index.php"><i class="fa fa-home" style='font-size:24px'></i> Home</a></li>
       
         <li class="x4" id="f12"><a href="mail.php"><i class="fa fa-fw fa-envelope" style='font-size:24px'></i>  Contact </a></li>
      
         <li class="x4" id="f13"><a href="menu.php"><i class="fa fa-bars" aria-hidden="true" style='font-size:24px'></i> Menu List</a></li>
     
         <li class="x4" id="f14"><a href="about.php"> <i class="fa fa-globe"></i> About</a></li>
      
         <li class="x4" id="f15"><a href="wishlist.php"><i class="fa fa-heart-o" style="font-size:24px"></i> Add Wish</a></li>
    
         <li class="x4" id="f16"><a href="Customer/login.php"><i class="fa fa-shopping-cart" style="font-size:24px"></i> Cart</a></li>
       
       
         <li class="x4"><i class="fa fa-fw fa-user" style='font-size:24px'></i> Sign In <i class="fa fa-caret-down"></i>
          
           
              <div class="dropdown-content">
              <a href="Restaurant_Owner/login1.php"><i class="fa fa-fw fa-user" style='font-size:24px'></i>Restaurant Owner Sign In</a>
              <a href="Customer/login.php"><i class="fa fa-fw fa-user" style='font-size:24px'></i>Customer Sign In</a>
              <a href="Delivery_Man/login2.php"><i class="fa fa-fw fa-user" style='font-size:24px'></i>Delivery Man Sign In</a>
              <a href="Waiter/login3.php"><i class="fa fa-fw fa-user" style='font-size:24px'></i>Waiter Sign In</a>
               </div>
           
      
      </li>

      </ul>

        

      

       
     </section>
     <script> 
             


             function InvalidMsg10(textbox) { 
       
                 if (textbox.value === '') { 
                     textbox.setCustomValidity ('Please Enter Your Name'); 
                 }  else { 
                     textbox.setCustomValidity(''); 
                 } 
       
                 return true; 
             } 
             function InvalidMsg11(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Email'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
   function InvalidMsg12(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Message'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
 
         </script> 
</body>
</html>   