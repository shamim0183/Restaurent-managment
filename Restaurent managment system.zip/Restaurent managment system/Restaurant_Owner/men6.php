<?php
$mysqli = new mysqli('localhost', 'root', '', 'admin');
 
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}

$food_name=$food_code=$food_price= $food_image=$price_tax=$catagory="";
$food_name_err=$food_code_err=$food_price_err= $food_image_err=$catagory_err=$price_tax_err="";

 
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    if(empty(trim($_POST["food_name"]))){
        $food_name_err = "Please enter a Food Name.";
    } else{
        
        
        $food_name = trim($_POST["food_name"]);
               
    }
    if(empty(trim($_POST["food_code"]))){
        $food_code_err = "Please enter a Food Code	.";
    } else{
        
        
        $food_code = trim($_POST["food_code"]);
               
    }
    if(empty(trim($_POST["food_price"]))){
        $food_price_err = "Please enter a Food Price.";
    } else{
        
        
        $food_price = trim($_POST["food_price"]);
               
    }

    if(empty(trim($_POST["catagory"]))){
        $catagory_err = "Please enter a Food Catagory.";
    } else{
        
        
        $catagory = trim($_POST["catagory"]);
               
    }

    

    if(empty(trim($_POST["price_tax"]))){
        $price_tax_err = "Please enter a Food Price.";
    } else{
        
        
        $price_tax = trim($_POST["price_tax"]);
               
    }
    

    $food_image = $_FILES["food_image"]["name"]; 
    $tempname = $_FILES["food_image"]["tmp_name"];     
    $folder = "../image/".$food_image; 

   
  if(empty(trim( $_FILES["food_image"]["name"]))){
       $food_image_err = "Please enter a Food Image.";
   } else{
        
       
     $food_image = trim( $_FILES["food_image"]["name"]);
               
	}
	
	

    if(empty($food_name_err) && empty($food_code_err)&& empty($food_price_err) && empty($catagory_err) && empty($food_image_err) && empty($price_tax_err)){
        
        $sql = "INSERT INTO food (food_name, food_code, food_price,catagory,price_tax,food_image) VALUES (?, ? , ?, ?, ?,?)";
         
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("ssssss",  $param_food_name,$param_food_code, $param_food_price,$param_catagory,$param_price_tax, $param_food_image);
            
            if (move_uploaded_file($tempname, $folder))  { 
                $food_image_err = "Image uploaded successfully"; 
            }else{ 
                $food_image_err = "Failed to upload image"; 
          } 
            
            $param_food_name= $food_name;
            $param_food_code=$food_code;
            $param_food_price=$food_price;
            $param_catagory=$catagory;
            $param_price_tax=$price_tax;

            $param_food_image=$food_image;
           
            if($stmt->execute()){
                echo '<script>alert("Add Food Menu Successfully")</script>';
				echo '<script>window.location="menu2.php"</script>';
                
            } else{
                echo '<script>alert("Something went wrong. Please try again later.")</script>';
				echo '<script>window.location="menu2.php"</script>';

            }
        }
         
        $stmt->close();
    }
    
    $mysqli->close();
}
?>
