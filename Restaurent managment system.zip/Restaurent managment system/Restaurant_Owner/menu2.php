<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Add Menu</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/body3.css">
    <style>
    
    #f3
{
    background-color:black;
    padding-left: 17px;
    padding-right: 17px;
    padding-top: 7px;
    padding-bottom: 7px;

}
#f3:hover
{
    background-color:green;
    padding-left: 17px;
    padding-right: 17px;
    padding-top: 7px;
    padding-bottom: 7px;
}
    
    </style>
</head>

<body>
       <?php include 'header2.php'; ?>
       <?php include 'men3.php'; ?>

       <?php include 'footer2.php'; ?>

</body>
</html>   