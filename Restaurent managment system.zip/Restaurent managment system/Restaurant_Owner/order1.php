<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Cart</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <style>
    
    #f6
{
    background-color:black;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 7px;
    padding-bottom: 7px;

}
#f6:hover
{
    background-color:green;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 7px;
    padding-bottom: 7px;
}
    
    </style>
</head>

<body>
       <?php include 'header2.php'; ?>
       <?php include 'or.php'; ?>

       <?php include 'footer2.php'; ?>

</body>
</html>   