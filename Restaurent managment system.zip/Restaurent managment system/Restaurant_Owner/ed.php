
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BBR</title>
        <link rel="icon" type="image/ico" href="../images/logo1.png" />
        <link rel="stylesheet" href="../styles/body3.css">
        <link rel="stylesheet" href="../styles/men3.css">  
          <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script>
               function previewFile(input){
               var file = $("input[type=file]").get(0).files[0];
              if(file){
                       var reader = new FileReader();
                       reader.onload = function(){
                       $("#previewImg").attr("src", reader.result);
                       }
                      reader.readAsDataURL(file);
                      {
                        var x = document.getElementById("myInput").value;
                        document.getElementById("demo").innerHTML = x;
                      }
                    }
              }
        </script>
    </head>
    <body>        
    <?php 
    	$db = mysqli_connect('localhost', 'root', '', 'admin');

	if (isset($_GET['edit'])) {
        $id = $_GET['edit'];

		$record = mysqli_query($db, "SELECT * FROM food WHERE id=$id");
        
		if (count($record) == 1 ) {
            
            $row = mysqli_fetch_array($record);
            $food_name=$row['food_name'];
            $food_code=$row['food_code'];

            $food_price=$row['food_price'];
            $catagory=$row['catagory'];

            $price_tax=$row['price_tax'];

            $food_image=$row['food_image'];

        
   
        
   echo  '<section class="cv1">
<p id="x1">Food</p>
<p id="x2"></p>
<p id="x3">MENU</p>
<p id="x4"></p>
<form id="WishlistForm" action="update5.php" method="post" enctype="multipart/form-data">
                            <br>
                            <div>
                               <input type="hidden" name="id" id="input1" Value='. $id.'>

                                <label for="Food_Name" id="label1">Food Name :</label>
                                <input type="text" id="input1" name="food_name" value='.$food_name.' oninvalid="InvalidMsg00(this);"  oninput="InvalidMsg00(this);" required>
                            </div>
                            <div>
                                <label for="Food_code" id="label1">Food Code :</label>
                                <input type="text" id="input1" name="food_code" value='.$food_code.' oninvalid="InvalidMsg001(this);"  oninput="InvalidMsg001(this);" required>
                            </div>
                            <div>
                                <label for="Food_Price" id="label1">Food Price :</label>
                                <input type="text" id="input1" name="food_price" value='.$food_price.'oninvalid="InvalidMsg002(this);"  oninput="InvalidMsg002(this);"  required>
                            </div>
                            <div>
                                <label for="Food_Catagory" id="label1">Food Catagory :</label>
                                <input type="text" id="input1" name="catagory" value='.$catagory.' oninvalid="InvalidMsg004(this);"  oninput="InvalidMsg004(this);" required>
                            </div>
                            <div>
                            <label for="Price_tax" id="label1">Price Tax:</label>
                            <input type="text" id="input1" name="price_tax" value='.$price_tax.' oninvalid="InvalidMsg003(this);"  oninput="InvalidMsg003(this);" required>
                        </div>
                            <div>
                            <img id="previewImg" src="../image/'.$food_image.'" alt="Placeholder" style="margin-left:570px">
 
                            </div>
                            <div>
                                <label for="uploadfoodimage" id="label1">Food Image Upload :</label>
                                <input type="file" id="input1" name="food_image" onchange="previewFile(this);" Value=""></input>
                            </div>
                           
                            
                            <div>
                                <input type="submit" name="update" style="margin-left:600px"id="Submit" value="Update">
                               <a href="men.php" id="view">View</a>

                            </div>
                           
                        </form>
                             
                   
<br><br>

<div></div>
<section>';
   }
}
?>
  </body>
</html>