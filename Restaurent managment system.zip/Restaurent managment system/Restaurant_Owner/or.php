<?php 
$mysqli = new mysqli('localhost', 'root', '', 'admin');
 
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}



?>
<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod3.css">	

</head>

<body>
<section class="cv">

		
			
		
			
			
			
<h3 style="color:white;margin-left:20px"><br>Customer Order Details</h3>
<div class="table-responsive" style="width:95%;margin-left:15px">
    <table class="table">
        <tr>
           <th  id="vb">Customer Name</th>
           <th  id="vb">Customer Id</th>
           <th  id="vb">Status</th>

            <th  id="vb">Food Name</th>
            <th  id="vb">Quantity</th>
            <th  id="vb">Price</th>
            <th  id="vb">Total</th>
            <th  id="vb">Action</th>
        </tr>
        <?php 

$status="";
$query = "SELECT * FROM order1 where status='place' ORDER BY Customer_Id ASC";
$total1=0;
$i=0;
$h=0;

if ($result = $mysqli->query($query)) {

/* fetch associative array */
while ($row = $result->fetch_assoc()) {
$id=$row['id'];
$Customer_Name = $row["Customer_Name"];
$Customer_Id = $row["Customer_Id"];

$food_name = $row["food_name"];
$quantity = $row["quantity"];
$price = $row["price"];
$total = $row["total"];
$total1=$total1+$total;
$status= $row["status"];
if($status==='place')
{

if($i==0)
{
    
    $a[$i]=$Customer_Id;

    $i++;

}
if($i>0)
{
    $a[$i]=$Customer_Id;
    if($a[$i-1]!=$Customer_Id)
    {
        $total2=$total1-$total+(($total1-$total)*2)/100;

        echo '<tr>
        <td colspan="6" align="right" id="vb1">Total (Incuding 2% Tax)</td>
        
        <td align="right" id="vb1">'.$total2.'Taka</td>
        <td id="vb1"></td>
        </tr>';
     $total1=$total;
        $i++;
        echo '<tr>
        <td id="vb1">'.$Customer_Name.'</td>
        <td id="vb1">'.$Customer_Id.'</td>
        <td id="vb1">'.$status.'</td>
        
        <td id="vb1">'.$food_name.'</td>
        <td id="vb1">'.$quantity.'</td>
        <td id="vb1">'.$price.' Taka</td>
        <td id="vb1">'.$total.' Taka</td>
        
        <td id="vb1"><a href="edit1.php?edit='.$id.'"style="margin-left:20px;"><i class="fa fa-edit" style="font-size:24px"></i>
        </a></td>
        </tr>';
    }
    else
    {
        
        echo '<tr>
<td id="vb1">'.$Customer_Name.'</td>
<td id="vb1">'.$Customer_Id.'</td>
<td id="vb1">'.$status.'</td>

<td id="vb1">'.$food_name.'</td>
<td id="vb1">'.$quantity.'</td>
<td id="vb1">'.$price.' Taka</td>
<td id="vb1">'.$total.' Taka</td>

<td id="vb1"><a href="edit1.php?edit='.$id.'"style="margin-left:20px;"><i class="fa fa-edit" style="font-size:24px"></i>
</a></td>
</tr>';

        $i++;

    }

}

}



}

/* free result set */
$result->free();
}
?>
<?php
if($status==='place')
{
?>
<tr>
    <td colspan="6" align="right" id="vb1">Total (Incuding 2% Tax)</td>
    <td align="right" id="vb1"><?php echo $total1+(($total1)*2)/100; ?> Taka</td>
    <td id="vb1"></td>
    </tr>

  <?php
}
  ?>      
        

            
    </table>
    
   <br>
</div>

</section>
</body>
</html>   



