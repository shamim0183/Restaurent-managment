<?php 
$db = mysqli_connect('localhost', 'root', '', 'admin');

if (isset($_POST['update'])) {
    
    $id = $_POST['id'];
    $status= $_POST["status"];


   
  
        mysqli_query($db, "UPDATE wish SET status='$status' WHERE id=$id");
        echo '<script>alert("Wish Menu Update Successfully")</script>';
        echo '<script>window.location="wishlist2.php"</script>';
    
  



}
?>