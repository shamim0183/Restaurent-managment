<?php
$mysqli = new mysqli('localhost', 'root', '', 'admin');
 
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}

$Customer_Name=$Customer_Email=$Wish_Food_Name= $Food_Code_No=$Table_Number="";
$Customer_Id=0;
$Customer_Name_err=$Customer_Email_err=$Wish_Food_Name_err= $Food_Code_No_err=$Table_Number_err="";
$Customer_Id_err=0;

 
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    if(empty(trim($_POST["Customer_Name"]))){
        $Customer_Name_err = "Please enter a Customer_Name.";
    } else{
        
        
        $Customer_Name = trim($_POST["Customer_Name"]);
               
    }
    if(empty(trim($_POST["Customer_Id"]))){
        $Customer_Id_err = "Please enter a Customer_Id	.";
    } else{
        
        
        $Customer_Id = trim($_POST["Customer_Id"]);
               
    }
    if(empty(trim($_POST["Customer_Email"]))){
        $Customer_Email_err = "Please enter a Customer_Email.";
    } else{
        
        
        $Customer_Email = trim($_POST["Customer_Email"]);
               
    }
    if(empty(trim($_POST["Wish_Food_Name"]))){
        $Wish_Food_Name_err = "Please enter a Wish_Food_Name.";
    } else{
        
        
        $Wish_Food_Name = trim($_POST["Wish_Food_Name"]);
               
    }
    if(empty(trim($_POST["Food_Code_No"]))){
        $Food_Code_No_err = "Please enter a Food_Code_No.";
    } else{
        
  

        $Food_Code_No= trim($_POST["Food_Code_No"]);
               
    }

    Table_Number
   
  if(empty(trim( $_POST["Table_Number"]))){
       $Table_Number_err = "Please enter a Table_Number.";
   } else{
        
       
     $Table_Number = trim( $_POST["Table_Number"]);
               
	}
	
	

    if(empty($Customer_Name_err) && empty($Customer_Id_err)&& empty($Customer_Email_err) && empty($Wish_Food_Name_err) && empty($Food_Code_No_err) && empty($Table_Number_err)){
        
        $sql = "INSERT INTO wish (Customer_Name, Customer_Id, Customer_Email, Wish_Food_Name,Food_Code_No,Table_Number) VALUES (?, ?, ?, ?, ?, ?)";
         
        if($stmt = $mysqli->prepare($sql)){
            $stmt->bind_param("ssssss",  $param_Customer_Name,$param_Customer_Id, $param_Customer_Email,  $param_Wish_Food_Name, $param_Food_Code_No, $param_Table_Number);
            
            if (move_uploaded_file($tempname, $folder))  { 
                $Image_err = "Image uploaded successfully"; 
            }else{ 
                $Image_err = "Failed to upload image"; 
          } 
            
            $param_Customer_Name= $Customer_Name;
            $param_Customer_Email=$Customer_Email;
            $param_Wish_Food_Name=$Wish_Food_Name;
            $param_Food_Code_No=$Food_Code_No;
            $param_Table_Number=$Table_Number;
            $param_Customer_Id=$Customer_Id;
            if($stmt->execute()){
                echo '<script>alert("Add Wish Successfully")</script>';
                echo '<script>window.location="afterindex1.php"</script>';
            } else{
                echo '<script>alert("Something went wrong. Please try again later.")</script>';
                echo '<script>window.location="wishlist2.php"</script>';

            }
        }
         
        $stmt->close();
    }
    
    $mysqli->close();
}
?>
