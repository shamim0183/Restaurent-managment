<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$connect = mysqli_connect("localhost", "root", "", "admin");  

if (isset($_GET['dele'])) {
	$id = $_GET['dele'];
	$query ="DELETE FROM food WHERE id=$id";
	$result1 = mysqli_query($connect, $query);  
	if($result1)
	{
		echo '<script>alert("Cancel Food Menu Iteam Successfully")</script>';
		echo '<script>window.location="men.php"</script>';
	}
	else
	{
		header('location: men.php');

	}
}
?>


















