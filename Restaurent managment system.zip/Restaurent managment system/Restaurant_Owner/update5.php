<?php 
$db = mysqli_connect('localhost', 'root', '', 'admin');

if (isset($_POST['update'])) {
    
    $id = $_POST['id'];
   

    $food_name=$_POST['food_name'];
    $food_code=$_POST['food_code'];
    $food_price=$_POST['food_price'];
    $price_tax=$_POST['price_tax'];

    $food_image=$_FILES['food_image']['name'];

    if($food_image=="")
    {
        mysqli_query($db, "UPDATE food SET food_name='$food_name', food_code='$food_code',food_price='$food_price',price_tax='$price_tax' WHERE id=$id");
        echo '<script>alert("Food Menu Update Successfully")</script>';
        echo '<script>window.location="menu2.php"</script>';
    }
   else
   {
    mysqli_query($db, "UPDATE food SET food_name='$food_name', food_code='$food_code',food_price='$food_price',price_tax='$price_tax',food_image='$food_image' WHERE id=$id");
    echo '<script>alert("Food Menu Update Successfully")</script>';
    echo '<script>window.location="menu2.php"</script>';
   }



}
?>