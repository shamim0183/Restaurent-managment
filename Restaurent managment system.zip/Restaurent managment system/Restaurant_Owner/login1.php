<!DOCTYPE html>
<html>
  <head>
    <title>BBR | Restaurant Owner Login </title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />

    <link rel="stylesheet" href="../styles/login.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital@1&display=swap" rel="stylesheet">

    </head>
    <body>
        <p>Restaurant Owner sign in & sign up </p>
<div class="login-form" action="log1.php" method="POST">
<input type="radio" name="tab" class="tab" id="sign-up-tab" checked>
<label for="sign-up-tab" class="tab-header" id="tab-header1">SIGN UP</label>
<input type="radio" name="tab" class="tab" id="sign-in-tab" checked>
<label for="sign-in-tab" class="tab-header">SIGN IN</label>
<form id="form2" action="log1.php" method="POST">
    <div class="header">WELLCOME BACK</div>
    <div class="form-input">
        <label class="label1">Restaurant Owner Name :</label>
        <input type ="text" class="input1" id="user-name" placeholder="Enter Restaurant Owner Name" name="username" oninvalid="InvalidMsg(this);"  oninput="InvalidMsg(this);" required>
    </div>
    <div class="form-input">
        <label class="label1">Password :</label>
        <input type ="password" class="input1" id="password" placeholder="Enter Password" name="passwordd" oninvalid="InvalidMsg2(this);"  oninput="InvalidMsg2(this);" required>
    </div>
        <div class="button1">
        <a href="forgetpassword1.php" id="a1">Lost Your Password?</a><br>
        <a href="../index.php"id="Cancel1">Cancel?</a>
       </div>
        <input type ="submit" id="sign-in" class="submit-button" value="SIGN IN">
        </form>
    <form id="form1" action="signup1.php" method="POST">
    <div class="header">SIGN UP FREE</div>
    <div class="form-input">
        <label class="label1">Restaurant Owner Name :</label>
        <input type ="text" class="input1" id="new-user-name" placeholder="Enter Restaurant Owner Name" name="username"oninvalid="InvalidMsg(this);"  oninput="InvalidMsg(this);" required>
    </div>
    <div class="form-input">
        <label class="label1">E-mail Adress :</label>
        <input type ="mail" class="input1" id="new-email" placeholder="Enter E-mail Address" name="email" oninvalid="InvalidMsg1(this);"  oninput="InvalidMsg1(this);"required>
    </div>
    <div class="form-input">
        <label class="label1">Conform E-mail Adress :</label>
        <input type ="mail" class="input1" id="conform-email2" placeholder="Enter Confarm E-mail Address" name="email1"oninvalid="InvalidMsg22(this);"  oninput="InvalidMsg22(this);" required>
    </div>
    <div class="form-input1">
    <label class="label1">Gender :</label>

    <input type="radio" name="tab" id="male" value="Male">Male
    <input type="radio" name="tab" id="female" value="Female">Female
    <br><br>
    </div>
    <div class="form-input">
        <label class="label1">New Password :</label>
        <input type ="password" class="input1" id="new-password" placeholder="Enter Password" name="passwordd" oninvalid="InvalidMsg2(this);"  oninput="InvalidMsg2(this);"required>
    </div>
    <div class="form-input">
        <label class="label1">Conform Password :</label>
        <input type ="password" class="input1" id="conform-password" placeholder="Enter Conform Password" name="password1" oninvalid="InvalidMsg3(this);"  oninput="InvalidMsg3(this);"required>
    </div>
        <div>
        <input type ="submit" id="sign-up" class="submit-button" value="SIGN UP">
    </div>
</form>
</div>
<script> 
                var p;
                var k;
                var k1;
               


        function InvalidMsg(textbox) { 
  
            if (textbox.value === '') { 
                textbox.setCustomValidity ('Please Enter Restaurant Owner Name'); 
            }  else { 
                textbox.setCustomValidity(''); 
            } 
  
            return true; 
        } 
       
     
        function InvalidMsg1(textbox) { 
         

            if (textbox.value === '') { 
                textbox.setCustomValidity ('Please Enter Email Address'); 
            } else if (textbox.validity.typeMismatch) { 
                textbox.setCustomValidity ('Please enter an email address which is valid!'); 
            } else { 
               k1 =textbox.value;
                textbox.setCustomValidity(''); 
            } 
  
            return true; 
        
    } 
   
    function InvalidMsg22(textbox) { 
         

         if (textbox.value === '') { 
             textbox.setCustomValidity ('Please Enter Email Address'); 
         }else if (textbox.validity.typeMismatch) { 
             textbox.setCustomValidity ('Please enter an email address which is valid!'); 
         }else if (textbox.value !=k1 ) { 
             textbox.setCustomValidity ('Confirm Email Does not Match'); 
         } else { 

             textbox.setCustomValidity(''); 
         } 

         return true; 
     
 } 
  

            function InvalidMsg2(textbox) { 

  if (textbox.value === '') { 
      textbox.setCustomValidity ('Please Enter Password'); 
  }else if(textbox.value.length<6){
    textbox.setCustomValidity ('Password must have atleast 6 characters.'); 

  }else if(textbox.value.length>10){

    textbox.setCustomValidity ('Password must less then 10 characters.'); 

  } else { 
    p=textbox.value;

      textbox.setCustomValidity(''); 
  } 

  return true; } 
  function InvalidMsg3(textbox) { 
  
  if (textbox.value === '') { 
      textbox.setCustomValidity ('Please Enter Conform Password'); 
  }else if(textbox.value.length<6){
    textbox.setCustomValidity ('Conform Password must have atleast 6 characters.'); 

  }else if(textbox.value.length>10){
    textbox.setCustomValidity ('Conform Password must less then 10 characters.'); 

  } else if(textbox.value!=p){
    textbox.setCustomValidity ('Password did not match'); 

  }  else { 

      textbox.setCustomValidity(''); 

  } 

    
  

  return true; } 

  
  
  
    </script> 
</body>
</html>