
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BBR</title>
        <link rel="icon" type="image/ico" href="../images/logo1.png" />
        <link rel="stylesheet" href="../styles/body3.css">
        <link rel="stylesheet" href="../styles/men4.css">  
          <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
       
    </head>
    <body>        
    <?php 
    	$db = mysqli_connect('localhost', 'root', '', 'admin');

	if (isset($_GET['edit'])) {
        $id = $_GET['edit'];

		$record = mysqli_query($db, "SELECT * FROM wish WHERE id=$id");
        
		if (count($record) == 1 ) {
            
            $row = mysqli_fetch_array($record);
            $Customer_Name =$row["Customer_Name"];
            $Customer_Id = $row["Customer_Id"];

            $Customer_Email =$row["Customer_Email"];
             $Wish_Food_Name = $row["Wish_Food_Name"];

             $Food_Code_No= $row["Food_Code_No"];
             $Table_Number= $row["Table_Number"];
             $status= $row["status"];


        
   
        
   echo  '<section class="cv1">
<p id="x1">Wish</p>
<p id="x2"></p>
<p id="x3">MENU</p>
<p id="x4"></p>
<form id="WishlistForm" action="update51.php" method="post" enctype="multipart/form-data">
                            <br>
                            <div>
                               <input type="hidden" name="id" id="input1" Value='. $id.'>

                                <label for="Customer_Name" id="label1">Customer Name :</label>
                                <p  id="u1">'.$Customer_Name.'</p>
                            </div>
                            <div>
                                <label for="Food_code" id="label1">Customer Id :</label>
                                <p id="u1">'.$Customer_Id.'</p>
                            </div>
                            <div>
                                <label for="Food_Price" id="label1">Customer Email :</label>
                                <p id="u1">'.$Customer_Email.'</p>
                            </div>
                            <div>
                                <label for="Wish_Food_Name" id="label1">Wish Food Name :</label>
                                <p id="u1">'.$Wish_Food_Name.'</p>
                            </div>
                            <div>
                            <label for="Food_Code_No" id="label1">Food Code No :</label>
                            <p id="u1">'.$Food_Code_No.'</p>
                            </div>
                            <div>
                                <label for="Table_Number" id="label1">Table_Number :</label>
                                <p id="u1">'.$Table_Number.'</p>
                            </div>
                            <div>
                            <label for="Status" id="label1">Status :</label>
                            <input type="text" id="input1" name="status" value='.$status.' oninvalid="InvalidMsg005(this);"  oninput="InvalidMsg005(this);" required>
                           </div>
                            
                            <div>
                                <input type="submit" name="update" style="margin-left:600px"id="Submit" value="Update">
                               <a href="wishlist2.php" id="view">View</a>

                            </div>
                           
                        </form>
                             
                   
<br><br>

<div></div>
<section>';
   }
}
?>
  </body>
</html>