<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Update Menu List</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />

</head>

<body>
       <?php include 'header2.php'; ?>
       <?php include 'ed.php'; ?>
       <?php include 'footer2.php'; ?>

</body>
</html>