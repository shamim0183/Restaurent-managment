<?php  
 $connect = mysqli_connect("localhost", "root", "", "admin");  
 $query = "SELECT * FROM registe2";  
 $result1 = mysqli_query($connect, $query);  
 while($row = mysqli_fetch_array($result1) )  
 {  
    $y=$row['id'];

     $x=$row['username'];




 }  
 ?> 
<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/header.css">
    <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
     <section class="x">
     <div class="y1"><a href="afterindex1.php"id="xc"><img src="../images/logo1.png" width="140px"height="140px" class="x1"></a>
    
    <p class="x2">Burgar Baba Restaurant</p>
</div>
     <ul class="p">
         <li class="x4" id="f1"><a href="afterindex1.php"><i class="fa fa-home" style='font-size:24px'></i> Home</a></li>
       
         <li class="x4"id="f2"><a href="mail2.php"><i class="fa fa-fw fa-envelope" style='font-size:24px'></i>  Contact </a></li>
      
       <li class="x4" id="f3"><a href="menu2.php"><i class="fa fa-bars" aria-hidden="true" style='font-size:24px'></i> Add Menu</a></li>
     
       <li class="x4" id="f4"><a href="about2.php"> <i class="fa fa-globe"></i> About</a></li>
      
       <li class="x4" id="f5"><a href="wishlist2.php"><i class="fa fa-heart-o" style="font-size:24px"></i> Wish List</a></li>
    
       <li class="x4" id="f6"><a href="order1.php"><i class="fa fa-shopping-cart" style="font-size:24px"></i> Order</a></li>
       
       
       <li class="x4" id="f7"><a href="delet3.php?dele=<?php echo $y; ?>"><i class="fas fa-sign-out-alt" style='font-size:24px'></i>Sign Out</a>  
          
           
            
           
      
      </li>

      </ul>

        

      

       
     </section>
     
</body>
</html>   