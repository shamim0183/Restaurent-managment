<!DOCTYPE html>
<html>

    <head>

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BBR</title>
        <link rel="icon" type="image/ico" href="../images/logo1.png" />
	    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
	       integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="../styles/footer.css">
        <link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
        <link href="https://fonts.googleapis.com/css?family=Prosto+One|Special+Elite" rel="stylesheet">
   </head>
   <body>
<div ></div>
        <section>
           
             <div class="manu2">
            <div class="man">
                
               
                <p>Follow Us</p>
            
                         <a href="#"><i id="k" class="fa fa-facebook-official" style="font-size:24px"></i></a>
                         <a href="#"><i id="m"class="fa fa-fw fa-envelope" style='font-size:24px'></i></i></a>
                          <a href="#"><i id="n1"class="fa fa-twitter" style="font-size:24px"></i></a>
                       
            </div>
            <div class="man1">
                
                
                  <p>Contract Information</p>
                  <i class="fa fa-map-marker" style="font-size:24px">
                  </i> 35/1 xxxxxxxxxxx, Dhaka-xxxx
              
              </div>
              <div class="man4">
                
                
                <p id="p12">Contract Us</p>
                <i id="n6" class="material-icons" >call</i> 018383826265
            
            </div>
            <div class="man5">
                
             
              <p id="p13">Support System</p>
              <i id="n9" class="fa fa-question-circle" style="font-size:24px"></i> Help<br>
              <i id="n10" class="fa fa-question-circle" style="font-size:24px"></i> FAQ<br> 
              <i id="n77" class="fa fa-lock" style="font-size:24px"></i>   Security<br>
          </div>
          <div class="man6">
                
           
            <p id="p14">Payment Metood</p>
            <i id="n15" class="fa fa-cc-paypal" style="font-size:24px"></i>       
            <i id="n16" class="fa fa-cc-visa" style="font-size:24px"></i>       
            <i id="n17" class="fa fa-credit-card" style="font-size:24px"></i>       
            <img id="n18" src="../images/bkash.png"width="24px"height="24px" >
        
        </div>
      
       
      </div>
      <div class="man44">
                
      <p id="p45">     <b>Copyright @ <?php
  $fromYear = 2019; 
  $thisYear = (int)date('Y'); 
  echo $fromYear . (($fromYear != $thisYear) ? '-' . $thisYear : '');?> Devoloped by : Burgar Baba Restaurant Team</b></p>

    
    </div>
        </section>
        <script> 
             


             function InvalidMsg10(textbox) { 
       
                 if (textbox.value === '') { 
                     textbox.setCustomValidity ('Please Enter Your Name'); 
                 }  else { 
                     textbox.setCustomValidity(''); 
                 } 
       
                 return true; 
             } 
             function InvalidMsg11(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Email'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
   function InvalidMsg12(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Message'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
 
         </script> 
           <script> 
             


             function InvalidMsg00(textbox) { 
       
                 if (textbox.value === '') { 
                     textbox.setCustomValidity ('Please Enter Your Food Name'); 
                 }  else { 
                     textbox.setCustomValidity(''); 
                 } 
       
                 return true; 
             } 
             function InvalidMsg001(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Food Code'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
   function InvalidMsg002(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Food Price'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
   function InvalidMsg003(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Price Tax'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
   function InvalidMsg004(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Your Food Catagory'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
   function InvalidMsg005(textbox) { 
       
       if (textbox.value === '') { 
           textbox.setCustomValidity ('Please Enter Status'); 
       }  else { 
           textbox.setCustomValidity(''); 
       } 

       return true; 
   } 
         </script> 
    </body>
	
</html>
