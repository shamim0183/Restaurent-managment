<?php
$mysqli = new mysqli('localhost', 'root', '', 'admin');
 
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
//call the FPDF library
require('fpdf17/fpdf.php');

//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm

//create pdf object
$pdf = new FPDF('P','mm','A4');
$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0, 0, 255);


//Cell(width , height , text , border , end line , [align] )
$pdf->AddPage();
$pdf->SetFont('Arial','B',14);

//Cell(width , height , text , border , end line , [align] )
$pdf->Image('fpdf17/logo1.png',5,0,30,30);

$pdf->Cell(130 ,5,'',0,5);
$pdf->Cell(130 ,5,'',0,5);
$pdf->Cell(130 ,5,'',0,5);
$pdf->SetTextColor(0, 0, 0);

$pdf->Cell(130 ,5,'Burger Baba Restaurant',0,0);

$pdf->Cell(59 ,5,'INVOICE',0,1);//end of line
$pdf->SetTextColor(0, 0, 255);

//set font to arial, regular, 12pt
$pdf->SetFont('Arial','',12);

$pdf->Cell(130 ,5,'Street Address : 26 Chamilibagh',0,0);
$pdf->Cell(59 ,5,'',0,1);//end of line

$pdf->Cell(130 ,5,'City : Dhaka, Country : Bangladesh, ZIP : 1217',0,0);
$pdf->Cell(25 ,5,'Date',0,0);
$pdf->Cell(34 ,5,date("Y/m/d"),0,1);//end of line

$pdf->Cell(130 ,5,'Phone : 01815420703',0,0);
$connect23 = mysqli_connect("localhost", "root", "", "admin");  

$query13= "SELECT * FROM registe1";  
 $result132 = mysqli_query($connect23, $query13);  
 while($row123 = mysqli_fetch_array($result132) )  
 {  
    $z=$row123['Customer_Id'];





 }  
 $query134= "SELECT * FROM register";  
 $result1324 = mysqli_query($connect23, $query134);  
 while($row1234 = mysqli_fetch_array($result1324) )  
 {  
    $z1=$row1234['Customer_Id'];





 }  
$query1 = "SELECT * FROM order1,register where order1.Customer_Id='$z' and order1.Customer_Id='$z1'";
$h=0;
if ($result1 = $mysqli->query($query1)) {

/* fetch associative array */
while ($row1 = $result1->fetch_assoc()) {
$Customer_Id = $z;
$username = $row1["username"];
$Mobile_Number = $row1["Mobile_Number"];
$Customer_Address = $row1["Customer_Address"];
$Company_Name = $row1["Company_Name"];

if($h==0)
{
    $pdf->Cell(25 ,5,'Invoice #',0,0);
   $pdf->Cell(34 ,5,$Customer_Id,0,1);//end of line
   $pdf->Cell(130 ,5,'Fax : +12345678',0,0);

    $pdf->Cell(25 ,5,'Customer ID:',0,0);
    $pdf->Cell(34 ,5,$Customer_Id,0,1);//end of line
    //make a dummy empty cell as a vertical spacer
$pdf->Cell(189 ,10,'',0,1);//end of line

$pdf->SetTextColor(0, 0, 0);

//billing address
$pdf->Cell(100 ,5,'Bill to',0,1);//end of line

//add dummy cell at beginning of each line for indentation
$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'Customer Name:      '.$username,0,1);

$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'Company Name:      '.$Company_Name,0,1);

$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'Customer Address:  '.$Customer_Address,0,1);

$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'Mobile Number:       '.$Mobile_Number,0,1);

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189 ,10,'',0,1);//end of line

    $h=1;
}

			

}

$result1->free();
}


//invoice contents
$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor(0, 0, 0);


/* free result set */

$pdf->Cell(70 ,7,'Food Name',1,0);
$pdf->Cell(35 ,7,'Price',1,0);
$pdf->Cell(35 ,7,'Quantity',1,0);

$pdf->Cell(39 ,7,'Amount',1,1);//end of line

$pdf->SetFont('Arial','',12);
$query134= "SELECT * FROM register";  
 $result1324 = mysqli_query($connect23, $query134);  
 while($row1234 = mysqli_fetch_array($result1324) )  
 {  
    $z1=$row1234['Customer_Id'];





 }  

$query = "SELECT * FROM order1 where order1.Customer_Id='$z' and order1.Customer_Id='$z1'";
$total1=0;
if ($result = $mysqli->query($query)) {

/* fetch associative array */
while ($row = $result->fetch_assoc()) {
$id=$row['id'];
$food_name = $row["food_name"];
$quantity = $row["quantity"];
$price = $row["price"];
$total = $row["total"];
$total1=$total1+$total;
$pdf->Cell(70 ,7,$food_name,1,0);
$pdf->Cell(35 ,7,$price,1,0);
$pdf->Cell(35 ,7,$quantity,1,0);
$pdf->Cell(39 ,7,$total,1,1,'R');//end of line


			

}

$result->free();
}
//Numbers are right-aligned so we give 'R' after new line parameter


//summary
$pdf->Cell(100 ,7,'',0,0);
$pdf->Cell(20 ,7,'Sub-Total',0,0);
$pdf->Cell(20 ,7,'Taka',1,0,'R');
$pdf->Cell(39 ,7,$total1,1,1,'R');//end of line



$pdf->Cell(100 ,7,'',0,0);
$pdf->Cell(20 ,7,'Tax Rate',0,0);
$pdf->Cell(20 ,7,'Taka',1,0,'R');
$pdf->Cell(39 ,7,'2%',1,1,'R');//end of line

$pdf->Cell(100 ,7,'',0,0);
$pdf->Cell(20 ,7,'Total Due',0,0);
$pdf->Cell(20 ,7,'Taka',1,0,'R');
$pdf->Cell(39 ,7,$total1+($total1*2)/100,1,1,'R');//end of line
$pdf->Output();
?>