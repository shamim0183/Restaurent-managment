<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>
<body>

<div style="height:200px;background-color:#c6cfc8">
<br>
<div style="border:3px solid black;width:30%;height:60%;margin-left:35%"><br><br>
<label style="margin-left:2%;  font-weight: bold;" for="cars">Choose Your Restaurant:</label>

<select name="cars" id="select" onchange="javascript:handleSelect(this)">
<option value="">Select a Restaurant </option>

  <option value="https://www.foodpanda.com.bd/">Food Panda</option>
  <option value="https://hungrynaki.com/">HungryNaki</option>
  <option value="https://pathao.com/food/">Pathao</option>
  <option value="https://www.shohoz.com/food">Shohoz</option>

  <option value="https://www.khaasfood.com/">Khaas Food</option>
  <option value="https://foodfex.com/">Foodfex</option>
  <option value="https://cookups.com.bd/">Cookups</option>
  <option value="http://www.kludioasia.com/">Kludio</option>

  <option value="index1.php">Burger Baba</option>

</select>
<script type="text/javascript">
  function handleSelect(elm)
  {
     window.location = elm.value;
  }
</script>
</div>

</div>
 




</body>
</html>