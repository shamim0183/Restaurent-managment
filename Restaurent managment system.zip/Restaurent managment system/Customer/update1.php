<?php 
$db = mysqli_connect('localhost', 'root', '', 'admin');

if (isset($_POST['add_to_cart'])) {
    
    $id = trim($_GET['id']);
    $price = trim($_POST["price"]);
    $food_name= trim($_POST["food_name"]);
    $quantity = trim($_POST["quantity"]); 
    $total1=$quantity*$price;
   

        mysqli_query($db, "UPDATE order1 SET quantity='$quantity', total='$total1' WHERE id=$id");
        echo '<script>alert("Update Order Successful")</script>';
        echo '<script>window.location="Cart.php"</script>';





}
?>