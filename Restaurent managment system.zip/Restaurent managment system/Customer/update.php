<?php 
$db = mysqli_connect('localhost', 'root', '', 'admin');

if (isset($_POST['update'])) {
    
    $id = $_POST['id'];
    $Customer_Name=$_POST['Customer_Name'];
    $Customer_Id=$_POST['Customer_Id'];

    $Customer_Email=$_POST['Customer_Email'];
    $Wish_Food_Name=$_POST['Wish_Food_Name'];
    $Food_Code_No=$_POST['Food_Code_No'];
    $Table_Number=$_POST['Table_Number'];

  
        mysqli_query($db, "UPDATE wish SET Customer_Name='$Customer_Name', Customer_Id='$Customer_Id',Customer_Email='$Customer_Email',Food_Code_No='$Food_Code_No', Wish_Food_Name='$Wish_Food_Name', Table_Number='$Table_Number' WHERE id=$id");
        echo '<script>alert("Update Wish Successful")</script>';
        echo '<script>window.location="view.php"</script>';

    
  



}
?>