<?php require_once('config.php'); ?>



<!DOCTYPE html>
<html>
  <head>
    <title>BBR | Customer Forget Password </title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />

    <link rel="stylesheet" href="../styles/forget.css">
    </head>
    <body>
        <p>Customer Forgot Password Here</p>
<div class="login-form">
<input type="radio" name="tab" class="tab" id="sign-up-tab" checked>
<label for="sign-up-tab" class="tab-header" id="tab-header1">Forgot Password</label>

    <form id="form1" action="forgetpassword.php" method="POST">
    <div class="header">Recover Password Here</div>
   
    <div class="form-input">
        <label class="label1">Customer Id :</label>
        <input type ="text" class="input1" id="new-user-id" placeholder="Enter Customer Id" name="Customer_Id" oninvalid="InvalidMsg23(this);"  oninput="InvalidMsg23(this);" required>
    </div>
  
    <div class="form-input">
        <label class="label1">E-mail Address :</label>
        <input type ="mail" class="input1" id="new-email" placeholder="Enter E-mail Address" name="email" oninvalid="InvalidMsg1(this);"  oninput="InvalidMsg1(this);" required>
    </div>
    
    
    
        <div>
        <input type ="submit" id="sign-up" class="submit-button" name="submit"value="Send Password Email">
        <a  href="login.php" style ="width:50px;height:10px;color:black;font-size:25px;text-decoration:none">Cancel?</a>

    </div>
</form>
</div>
<script> 
               
        function InvalidMsg23(textbox) { 
  
  if (textbox.value === '') { 
      textbox.setCustomValidity ('Please Enter Customer Id'); 
  }  else { 
      textbox.setCustomValidity(''); 
  } 

  return true; 
} 


     
        function InvalidMsg1(textbox) { 
         

            if (textbox.value === '') { 
                textbox.setCustomValidity ('Please Enter Email Address'); 
            } else if (textbox.validity.typeMismatch) { 
                textbox.setCustomValidity ('Please enter an email address which is valid!'); 
            } else { 
                textbox.setCustomValidity(''); 
            } 
  
            return true; 
        
    } 
   
   

         
    
  


  
  
  
    </script> 
</body>

</html>