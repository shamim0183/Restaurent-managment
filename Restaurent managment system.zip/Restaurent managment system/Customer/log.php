<?php	
	$mysqli = new mysqli('localhost', 'root', '', 'admin');
	
	if($mysqli === false){
		die("ERROR: Could not connect. " . $mysqli->connect_error);
	}
	
	$username = $password = $Customer_Id ="";
	$username_err = $password_err =$Customer_Id_err = "";
	// Processing form data when form is submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	
		// Check if username is empty
		if(empty(trim($_POST["username"]))){
			$username_err = "Please enter username.";
		} else{
			$username = trim($_POST["username"]);
		}
		// Check if password is empty
		if(empty(trim($_POST["passwordd"]))){
			$password_err = "Please enter your password.";
		} else{
      $password = trim($_POST["passwordd"]);
		}

		if(empty(trim($_POST["Customer_Id"]))){
			$Customer_Id_err = "Please enter Customer Id.";
		} else{
			$Customer_Id = trim($_POST["Customer_Id"]);
		}

		if(empty($username_err) && empty($password_err)&& empty($Customer_Id_err)){
		$sql="SELECT * FROM register WHERE username='$username' AND passwordd='$password' AND Customer_Id =$Customer_Id  LIMIT 1";
		$sql1 = "INSERT INTO registe1 (username,passwordd,Customer_Id) VALUES ('$username','$password','$Customer_Id')";
			if($result = $mysqli->query($sql) )
			{
				if($result->num_rows > 0)
				{
					if($result1 = $mysqli->query($sql1))
                    {
						
					   echo '<script>alert("Customer Login Successful")</script>';
		               echo '<script>window.location="afterindex.php"</script>';
						//$_SESSION[user]=$username;
					}
					
				}
				else
				{
					
					echo '<script>alert("Username or Password or Customer Id is wrong!")</script>';
		            echo '<script>window.location="login.php"</script>';
					
				}
			}
		}
	}
?>

