<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Wish List</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/body5.css">

</head>

<body>
       <?php include 'header1.php'; ?>
       <?php include 'tody6.php'; ?>
       <?php include 'footer1.php'; ?>

</body>
</html>