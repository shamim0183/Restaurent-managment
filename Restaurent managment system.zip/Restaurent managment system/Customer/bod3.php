  
<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RMS</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod3.css">	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
	</head>
	<body>
    <section class="cv">

		
			
		
			
			
			
			<h3 style="color:white;margin-left:20px"><br>Food Order Details <a style="color:white;margin-left:790px;text-decoration:none;background-color:orange;padding:3px;border-radius:5px;" href="../test.php"><i class="fa fa-file-pdf-o" style="font-size:24px;color:white"></i> INVOICE PDF</a></h3>
			<div class="table-responsive" style="width:95%;margin-left:15px">
				<table class="table">
					<tr>
						<th  id="vb">Food Name</th>
						<th  id="vb">Quantity</th>
						<th  id="vb">Price</th>
						<th  id="vb">Total</th>
						<th  id="vb">Action</th>
					</tr>
					<?php 
$mysqli = new mysqli('localhost', 'root', '', 'admin');
 
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}

$connect23 = mysqli_connect("localhost", "root", "", "admin");  

$query13= "SELECT * FROM registe1";  
 $result1 = mysqli_query($connect23, $query13);  
 while($row = mysqli_fetch_array($result1) )  
 {  
    $z=$row['Customer_Id'];





 }  

$query = "SELECT order1.id,order1.food_name,order1.quantity,order1.price,order1.total,order1.Customer_Id,order1.status FROM order1 where order1.Customer_Id='$z'";
$total1=0;
$status="";
if ($result = $mysqli->query($query)) {

/* fetch associative array */
while ($row = $result->fetch_assoc()) {
$id=$row['id'];
$food_name = $row["food_name"];
$quantity = $row["quantity"];
$price = $row["price"];
$total = $row["total"];
$total1=$total1+$total;
$status= $row["status"];
if($status==='place')
{
	echo '<tr>
	<td id="vb1">'.$food_name.'</td>
	<td id="vb1">'.$quantity.'</td>
	<td id="vb1">'.$price.' Taka</td>
	<td id="vb1">'.$total.' Taka</td>
	
	<td id="vb1"><a href="delet9.php?id='.$id.'"><i class="fa fa-trash-o" style="font-size:24px"></i></a><a href="edit1.php?edit='.$id.'"style="margin-left:20px;"><i class="fa fa-edit" style="font-size:24px"></i>
	</a></td>
</tr>';
}
if($status==='')
{
	echo '<tr>
	<td id="vb1"> </td>
	<td id="vb1"> </td>
	<td id="vb1">  </td>
	<td id="vb1"> </td>
	
	<td id="vb1"> </td>
</tr>';
}
else
{
	echo '<tr>
	<td id="vb1" colspan="4" style="text-align:center">Order is Processing</td>
	
	
	<td id="vb1"> </td>
</tr>';
}
			

}

/* free result set */
$result->free();
}
?>
<?php
if($status==='place')
{
?>
<tr>
<td colspan="3" align="right" id="vb1">Total (Incuding 2% Tax)</td>
<td align="right" id="vb1"><?php echo $total1+($total1*2)/100 ;?> Taka</td>
<td id="vb1"></td>
</tr>
<?php
}


?>
					
					
				
						
				</table>
                
               <br>
			</div>
		
    </section>
    
	</body>
</html>



