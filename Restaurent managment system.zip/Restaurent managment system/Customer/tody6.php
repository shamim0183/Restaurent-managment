
<!DOCTYPE html>
<html>
    <head>
    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>BBR</title>
        <link rel="icon" type="image/ico" href="../images/logo1.png" />
        <link rel="stylesheet" href="../styles/body5.css">
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      
    </head>
    <body> 

    <?php 
    	$db = mysqli_connect('localhost', 'root', '', 'admin');

	if (isset($_GET['edit'])) {
		$id = $_GET['edit'];
		$record = mysqli_query($db, "SELECT * FROM wish WHERE id=$id");

		if (count($record) == 1 ) {
            $row = mysqli_fetch_array($record);
            $Customer_Name=$row['Customer_Name'];
            $Customer_Id=$row['Customer_Id'];

            $Customer_Email=$row['Customer_Email'];
            $Wish_Food_Name=$row['Wish_Food_Name'];
            $Food_Code_No=$row['Food_Code_No'];
            $Table_Number=$row['Table_Number'];

        }
     ?>
     <section>
             <h2 class="tes"></h2>
        </section>
       <section>
             <h2 class="tes1">  
     <?php
      echo '<form id="registrationForm" action="update.php" method="post" enctype="multipart/form-data">
                            <h4>For any kind of enquiry, please</h4>
                            <h1>Leave A Message</h1>
                            <p id="p1">*All fields are required.</p>
                            <div class="formw">
                            <div>
                            <input type="hidden" name="id" id="i1" Value='. $id.'>

                            </div>
                            <div>
                                <label for="Name" id="label1">Customer Name :</label>
                                <input type="text" id="i1" name="Customer_Name" Value='. $Customer_Name.' >
                            </div>
                            <div>
                                 <br><br>
                                <label for="userid" id="label1">Customer ID :</label>
                                <input type="text" id="i2" name="Customer_Id" Value='. $Customer_Id.' >
                            </div>
                            <div>
                            <br><br>

                                <label for="mailEmail" id="label1">Customer Email :</label>
                                <input type="email" id="i3" name="Customer_Email" Value='. $Customer_Email.'>
                            </div>
                            <div>
                            <br><br>

                                <label for="WishFoodName" id="label1">Wish Food Name :</label>
                                <input type="text" id="i4" name="Wish_Food_Name" Value='. $Wish_Food_Name.'>
                            </div>
                            <div>
                            <br><br>

                                <label for="foodcodeno" id="label1">Food Code No :</label>
                                <input type="text" id="i5" name="Food_Code_No" Value='. $Food_Code_No.' >
                            </div>
                            <div>
                            <br><br>

                            <label for="Table_Number" id="label1">Table Number :</label>
                            <input type="text" id="i5" name="Table_Number" Value='. $Table_Number.'>
                            <br><br>

                            </div>
                           
                            <div>
                                <input type="reset"  id="reset" value="Clear">

                                <input type="submit" name="update" id="Submit" value="Update">
                                <a href="view.php" style="margin-left:15px;text-decoration:none;Background-color:blue;padding:4px;color:white;border-radius:15px;border:2px solid black">View</a>

                            </div>
                            <br>
                            </div>
                        </form>   ';     

	}
?>        
       </h2>                       
  </body>
</html>