
<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod2.css">	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
	</head>
	<body>
    <section class="cv">

		<br />
		<div class="container" >
			<br />
			<br />
			<h3 align="center" style="border-style: double;color:white;background-color:black" >Food Menu</h3><br />
			<br /><br />
			<?php
	 $connect = mysqli_connect("localhost", "root", "", "admin");  

			    $query2 = "SELECT * FROM registe1";  
				$result1 = mysqli_query($connect, $query2);  
				while($row1 = mysqli_fetch_array($result1) )  
				{  
				   $y=$row1['id'];
			   
					$x=$row1['username'];
			   
			       $z=$row1['Customer_Id'];
			   
			   
				}  
				$query = "SELECT * FROM food ORDER BY id ASC";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
						$Image=$row["food_image"];
				?>
			<div class="col-md-4">
				<form method="post" action="Cart.php">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="../image/<?php echo $row["food_image"]; ?>" class="img-responsive" /><br />
      
						<h4 class="text-info"><?php echo $row["food_name"]; ?></h4>

						<h4 class="text-danger"><?php echo $row["food_price"]; ?> Taka</h4>

						<input type="text" style="text-align:center"name="quantity" value="1" class="form-control" />

						<input type="hidden" name="food_name" value="<?php echo $row["food_name"]; ?>" />
						<input type="hidden" name="Customer_Name" value="<?php echo $x; ?>" />
						<input type="hidden" name="Customer_Id" value="<?php echo $z; ?>" />
						<input type="hidden" name="status" value="place" />

						<input type="hidden" name="Image" value="<?php echo $Image; ?>" />

						<input type="hidden" name="price" value="<?php echo $row["food_price"]; ?>" />
						<input type="hidden" name="price_tax" value="<?php echo $row["price_tax"]; ?>" />

						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Add to Cart" />

					</div>
					<br>
				</form>
			</div>
			
			<?php
					}
				}
			?>
			<div style="clear:both"></div>
			<br />
			<div class="table-responsive">
				

			</div>
		</div>
	</div>
    </section>
    
	</body>
</html>



