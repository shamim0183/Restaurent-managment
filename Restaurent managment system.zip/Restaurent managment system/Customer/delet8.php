<?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$connect = mysqli_connect("localhost", "root", "", "admin");  

if (isset($_GET['dele'])) {
	$id = $_GET['dele'];
	$query ="DELETE FROM wish WHERE id=$id";
	$result1 = mysqli_query($connect, $query);  
	if($result1)
	{
		echo '<script>alert("Wish Cancel Successfully")</script>';
		echo '<script>window.location="view.php"</script>';

	}
	else
	{
		header('location: view.php');

	}
}
?>


















