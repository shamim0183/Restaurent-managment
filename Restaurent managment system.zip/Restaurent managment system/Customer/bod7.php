  


<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod3.css">	
    
	</head>
	<body>
    <section class="cv">

		
			
		
			
			
			
			<h3 style="color:white;margin-left:20px"><br>Wish List Details</h3>
			<div class="table-responsive" style="width:95%;margin-left:15px">
				<table class="table">
					<tr>
						<th  id="vb">Customer Name</th>
						<th  id="vb">Customer Id</th>
                        <th  id="vb">Food Code No</th>

                        <th  id="vb">Wish Food Name</th>
                        <th  id="vb">Table Number</th>
                        <th  id="vb">Status</th>

                        <th  id="vb">Action</th>

					</tr>
                    <?php 

                       $mysqli = new mysqli('localhost', 'root', '', 'admin');
 
                           if($mysqli === false){
                           die("ERROR: Could not connect. " . $mysqli->connect_error);
                         }
$query = "SELECT * FROM wish";

if ($result = $mysqli->query($query)) {

    /* fetch associative array */
    while ($row = $result->fetch_assoc()) {
        $id=$row['id'];
        $Customer_Name = $row["Customer_Name"];
        $Customer_Id = $row["Customer_Id"];
        $Wish_Food_Name = $row["Wish_Food_Name"];
        $Food_Code_No = $row["Food_Code_No"];
        $Table_Number = $row["Table_Number"];
        $status = $row["status"];

        echo '<tr> 
        <td id="vb1">'.$Customer_Name.'</td> 
        <td id="vb1">'.$Customer_Id.'</td> 
        <td id="vb1">'.$Food_Code_No.'</td> 


        <td id="vb1">'.$Wish_Food_Name.'</td> 
        <td id="vb1">'.$Table_Number.'</td> 
        <td id="vb1">'.$status.'</td> 

        <td id="vb1"><a href="delet8.php?dele='.$id.'"><i class="fa fa-trash-o" style="font-size:24px"></i></a><a href="edit.php?edit='.$id.'" style="margin-left:20px;"><i class="fa fa-edit" style="font-size:24px"></i>
        </a></td> 

        </tr>';
    }

    /* free result set */
    $result->free();
}
?>
				 	
					
					
					
						
				</table>
                
               <br>
			</div>
		
    </section>
    
	</body>
</html>



