
<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod25.css">	
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	
	</head>
	<body>
    <section class="cv">

		<br />
		<div class="container" >
			<br />
			<br />
			<h3 align="center" style="color:black;" >Food Menu</h3><br />
			<br /><br />
			<?php
            $mysqli = new mysqli('localhost', 'root', '', 'admin');
 
            if($mysqli === false){
                die("ERROR: Could not connect. " . $mysqli->connect_error);
            }
			    $query2 = "SELECT * FROM registe1";  
				$result1 = mysqli_query($connect, $query2);  
				while($row1 = mysqli_fetch_array($result1) )  
				{  
			   
					$x=$row1['username'];
					$y=$row1['Customer_Id'];

			   
			   
			   
                }  
                if (isset($_GET['edit'])) {
                    $id = $_GET['edit'];
				$query = "SELECT * FROM order1 where id=$id";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
				?>
			<div class="col-md-4" style="margin-left:350px">
				<form method="post" action="update1.php?id=<?php echo $id; ?>">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="../image/<?php echo $row["Image"]; ?>" class="img-responsive" /><br />
      
						<h4 class="text-info"><?php echo $row["food_name"]; ?></h4>

						<h4 class="text-danger"><?php echo $row["price"]; ?> Taka</h4>

						<input type="text" name="quantity" style="text-align:center" value="1" class="form-control" />

						<input type="hidden" name="food_name" value="<?php echo $row["food_name"]; ?>" />
						<input type="hidden" name="Customer_Name" value="<?php echo $x; ?>" />
						<input type="hidden" name="Customer_Id" value="<?php echo $y; ?>" />

						<input type="hidden" name="price" value="<?php echo $row["price"]; ?>" />
                        
						<input type="submit" name="add_to_cart" style="margin-top:5px;" class="btn btn-success" value="Update to Cart" />

					</div>
					<br>
				</form>
			</div>
			
			<?php
					}
                }
            }
			?>
			<div style="clear:both"></div>
			<br />
			<div class="table-responsive">
				

			</div>
		</div>
	</div>
    </section>
    
	</body>
</html>



