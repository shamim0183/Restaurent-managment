<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../styles/body2.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>

<body>
<section class="cv">
<div id="slider">
<figure>
<img src="../images/page2_img1.jpg" alt>
<img src="../images/page2_img2.jpg" alt>
<img src="../images/page2_img3.jpg" alt>
<img src="../images/page2_img4.jpg" alt>
<img src="../images/page2_img5.jpg" alt>
</figure>
</div>
<section>
</body>
</html>   




