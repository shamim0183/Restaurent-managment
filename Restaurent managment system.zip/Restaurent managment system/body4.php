<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="images/logo1.png" />
    <link rel="stylesheet" href="styles/body4.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>	

</head>

<body>
<section class="cv1">
<p id="gh2">About</p>
<p id="gh3"> Burger Baba Restaurant Main aim reach satisfaction level of Customer. We serve food offine and home delivery. We ensure our food quality. You can suggested any kind of new food or food review our site to improve  food quality. Our Restaurant establist in 2020 at 1 October. </p>
<p id="gh4"> Food Special Offer </p>
<div class="container" >
			<br />
			<br />
			<?php
 
                $connect = mysqli_connect("localhost", "root", "", "admin");  

				$query = "SELECT * FROM food ORDER BY food_price DESC limit 6";
				$result = mysqli_query($connect, $query);
				if(mysqli_num_rows($result) > 0)
				{
					while($row = mysqli_fetch_array($result))
					{
						$Image=$row["food_image"];
				?>
			<div class="col-md-4">
					<div style="border:1px solid #333; background-color:#f1f1f1; border-radius:5px; padding:16px;" align="center">
						<img src="image/<?php echo $row["food_image"]; ?>" class="img-responsive" /><br />
      
						<h4 class="text-info"><?php echo $row["food_name"]; ?></h4>

						<h4 class="text-danger"><?php echo $row["food_price"]; ?> Taka</h4>


						<input type="hidden" name="food_name" value="<?php echo $row["food_name"]; ?>" />
						<input type="hidden" name="Customer_Name" value="<?php echo $x; ?>" />
						<input type="hidden" name="Customer_Id" value="<?php echo $z; ?>" />
						<input type="hidden" name="status" value="place" />

						<input type="hidden" name="Image" value="<?php echo $Image; ?>" />

						<input type="hidden" name="price" value="<?php echo $row["food_price"]; ?>" />
						<input type="hidden" name="price_tax" value="<?php echo $row["price_tax"]; ?>" />


					</div>
					<br>
			</div>
			
			<?php
					}
				}
			?>
			<div style="clear:both"></div>
			<br />
			<div class="table-responsive">
				

			</div>
		</div>
	</div>
<section>
</body>
</html>   



