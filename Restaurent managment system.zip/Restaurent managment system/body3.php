<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="images/logo1.png" />
    <link rel="stylesheet" href="styles/body3.css">

</head>

<body>
<section class="cv1">
<p id="x1">Food</p>
<p id="x2"></p>
<p id="x3">MENU</p>
<p id="x4"></p>
<table id="x5">
  <tr>
    <th id="x6">Food Code No</th>

    <th id="x6">Food Name</th>
    <th id="x6">Price</th>
    <th id="x6">Catagory</th>

  </tr>
  <?php 

$mysqli = new mysqli('localhost', 'root', '', 'admin');

    if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
  }
$query = "SELECT * FROM food";

if ($result = $mysqli->query($query)) {

/* fetch associative array */
while ($row = $result->fetch_assoc()) {
$food_code=$row['food_code'];
$food_name = $row["food_name"];
$food_price = $row["food_price"];
$food_catagory = $row["catagory"];


echo '<tr> 
<td id="x6">'.$food_code.'</td> 
<td id="x6">'.$food_name.'</td> 
<td id="x6">'.$food_price.' Taka</td> 
<td id="x6">'.$food_catagory.'</td> 

</tr>';
}

/* free result set */
$result->free();
}
?>
  
</table>


<br><br>

<div></div>
<section>
</body>
</html>   



