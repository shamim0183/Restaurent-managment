<?php	
	session_start();
	$mysqli = new mysqli('localhost', 'root', '', 'admin');
	
	if($mysqli === false){
		die("ERROR: Could not connect. " . $mysqli->connect_error);
	}
	
	$username = $password = $delivery_man_id="";
	$username_err = $password_err = $delivery_man_id_err= "";
	// Processing form data when form is submitted
	if($_SERVER["REQUEST_METHOD"] == "POST"){
	
		// Check if username is empty
		if(empty(trim($_POST["username"]))){
			$username_err = "Please enter username.";
		} else{
			$username = trim($_POST["username"]);
		}
		// Check if password is empty
		if(empty(trim($_POST["passwordd"]))){
			$password_err = "Please enter your password.";
		} else{
      $password = trim($_POST["passwordd"]);
		}

		if(empty(trim($_POST["delivery_man_id"]))){
			$delivery_man_id_err = "Please enter Delivery Man Id.";
		} else{
			$delivery_man_id = trim($_POST["delivery_man_id"]);
		}

		if(empty($username_err) && empty($password_err)&& empty($delivery_man_id_err)){
		$sql="SELECT * FROM register2 WHERE username='$username' AND passwordd='$password' AND delivery_man_id='$delivery_man_id' LIMIT 1";
		$sql1 = "INSERT INTO registe3 (username,passwordd,delivery_man_id) VALUES ('$username','$password','$delivery_man_id')";
			if($result = $mysqli->query($sql) )
			{
				if($result->num_rows > 0)
				{
					if($result1 = $mysqli->query($sql1))
                    {
						echo '<script>alert("Delivery Man Login Successfully")</script>';
		                echo '<script>window.location="afterindex2.php"</script>';
						$_SESSION[user]=$username;
					}
					
				}
				else
				{
					echo '<script>alert("Username or Password is wrong!")</script>';
		            echo '<script>window.location="login2.php"</script>';
				}
			}
		}
	}
?>