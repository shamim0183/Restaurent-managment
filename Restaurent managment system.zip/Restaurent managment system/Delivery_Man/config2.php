<?php
   
   $mysqli = new mysqli('localhost', 'root', '', 'admin');
 
   if($mysqli === false){
       die("ERROR: Could not connect. " . $mysqli->connect_error);
   }
   
    if(isset($_POST['submit'])){
        $mailEmail = $_POST['email'];

        $query = "SELECT * FROM register2 where email='$mailEmail'";

if ($result = $mysqli->query($query)) {

    /* fetch associative array */
    while ($row = $result->fetch_assoc()) {
        $Customer_Name = $row["username"];
        
        $password= $row["passwordd"];

        $mailName =  "Burger Baba Restaurant";


    }

    /* free result set */
    $result->free();
}


$param_password = $password;

$mailMessage =$param_password;
$mailEmail1="tipusultan9t7a@gmail.com";
        $formcontent="From: $mailName \nSender Email: $mailEmail1 \nPassword: $mailMessage";
        $recipient =$mailEmail;
        $subject = "Recover Password";
        $mailheader = "From: $mailEmail \r\n" . "CC: tipusultan9t7a@gmail.com";

        mail($recipient, $subject, $formcontent, $mailheader) or die("Error!");
        
    }
?>