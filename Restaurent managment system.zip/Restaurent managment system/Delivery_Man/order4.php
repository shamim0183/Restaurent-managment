<?php 
	 $connect = mysqli_connect("localhost", "root", "", "admin");

     $sql ='';
if(isset($_POST["add_to_cart"]))
{
		$Customer_Name = trim($_POST["Customer_Name"]);
		$Customer_Id = trim($_POST["Customer_Id"]);

        $price = trim($_POST["price"]);
        $price_tax = trim($_POST["price_tax"]);

        $food_name= trim($_POST["food_name"]);
		$quantity = trim($_POST["quantity"]); 
		$total1=$quantity*$price;
		$Image=trim($_POST["Image"]); 
		$status=trim($_POST["status"]); 

   
	   
	

        
        $sql .= 'INSERT INTO order1 (food_name,Customer_Name,Customer_Id,quantity, price, total,Image,status,price_tax) VALUES ( "'.$food_name.'","'.$Customer_Name.'","'.$Customer_Id.'","'.$quantity.'", "'.$price.'","'.$total1.'","'.$Image.'","'.$status.'","'.$price_tax.'")';
         
        if($sql != '')
        {
         if(mysqli_multi_query($connect, $sql))
         {
       //   echo 'Item Data Inserted';
         }
         else
         {
      //    echo 'Error';
         }
        }
       
        else
        {
        // echo 'All Fields are Required';
        }

}

?>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Cart</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />

    <style>
    
    #f36
{
    background-color:black;
    padding-left: 17px;
    padding-right: 17px;
    padding-top: 7px;
    padding-bottom: 7px;

}
#f36:hover
{
    background-color:green;
    padding-left: 17px;
    padding-right: 17px;
    padding-top: 7px;
    padding-bottom: 7px;
}
    
    </style>
</head>

<body>
       <?php include 'header3.php'; ?>
       <?php include 'or4.php'; ?>
     
       <?php include 'footer3.php'; ?>

</body>
</html>   