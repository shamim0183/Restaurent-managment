  


<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/bod3.css">	
    
	</head>
	<body>
    <section class="cv">

		
			
		
			
			
			
			<h3 style="color:white;margin-left:20px"><br>Delivery List Details <a style="color:white;margin-left:790px;text-decoration:none;background-color:orange;padding:3px;border-radius:5px;" href="../test1.php"><i class="fa fa-file-pdf-o" style="font-size:24px;color:white"></i> INVOICE PDF</a></h3>
			<div class="table-responsive" style="width:95%;margin-left:15px">
				<table class="table">
					<tr>
						<th  id="vb">Customer Name</th>
						<th  id="vb">Customer Id</th>
             <th  id="vb">Total</th>

             <th  id="vb">Customer Address</th>
             <th  id="vb">Company Name</th>
             <th  id="vb">Email</th>
             <th  id="vb">Mobile Number</th>
          

					</tr>
                    <?php 

                       $mysqli = new mysqli('localhost', 'root', '', 'admin');
 
                           if($mysqli === false){
                           die("ERROR: Could not connect. " . $mysqli->connect_error);
                         }


$query1 = "SELECT * FROM order1";

$total5 = 0;

if ($result = $mysqli->query($query1)) {

    /* fetch associative array */
    while ($row = $result->fetch_assoc()) {
        $id=$row['id'];
        $Customer_Name = $row["Customer_Name"];
        $Customer_Id = $row["Customer_Id"];
        $price_tax = $row["price_tax"];

        $query = "SELECT order1.total,order1.status FROM order1 where order1.status='processing'";
        
        if ($result1 = $mysqli->query($query)) {
        
          /* fetch associative array */
          while ($row2 = $result1->fetch_assoc()) {
              $total=$row2['total'];
              $total5 += $total;
        
          }
          $total6= $total5+($total5*$price_tax)/100;

          /* free result set */
          $result1->free();
        }

        $query5 = "SELECT register.Customer_Id,register.Customer_Address,register.Company_Name,register.email,register.Mobile_Number FROM register where register.Customer_Id='$Customer_Id'";
        
        if ($result134 = $mysqli->query($query5)) {
        
          /* fetch associative array */
          while ($row22 = $result134->fetch_assoc()) {
              $Customer_Address=$row22['Customer_Address'];
              $Company_Name=$row22['Company_Name'];
              $email=$row22['email'];
              $Mobile_Number=$row22['Mobile_Number'];
             

        
          }

          /* free result set */
          $result134->free();
        }

        echo '<tr> 
        <td id="vb1" style="text-align:center">'.$Customer_Name.'</td> 
        <td id="vb1" style="text-align:center">'.$Customer_Id.'</td> 

        <td id="vb1" style="text-align:center">'.$total6.'</td> 

        <td id="vb1" style="text-align:center">'.$Customer_Address.'</td> 
        <td id="vb1" style="text-align:center">'.$Company_Name.'</td> 
        <td id="vb1" style="text-align:center">'.$email.'</td> 
        <td id="vb1" style="text-align:center">'.$Mobile_Number.'</td> 
       

        </tr>';
    }

    /* free result set */
    $result->free();
}
?>
				 	
					
					
					
						
				</table>
                
               <br>
			</div>
		
    </section>
    
	</body>
</html>



