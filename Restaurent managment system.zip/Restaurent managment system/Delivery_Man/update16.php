<?php 
$db = mysqli_connect('localhost', 'root', '', 'admin');

if (isset($_POST['add_to_cart'])) {
    
    $id = trim($_GET['id']);
    $status = trim($_POST["status"]);

   

        mysqli_query($db, "UPDATE order1 SET status='$status' WHERE id=$id");
        echo '<script>alert("Update Order Successful")</script>';
        echo '<script>window.location="order4.php"</script>';





}
?>