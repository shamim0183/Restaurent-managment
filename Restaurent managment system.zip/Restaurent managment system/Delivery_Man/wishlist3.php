<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Delivery List</title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />
    <link rel="stylesheet" href="../styles/body5.css">
    <style>
    
    #f35
{
    background-color:black;
    padding-left: 17px;
    padding-right: 17px;
    padding-top: 7px;
    padding-bottom: 7px;

}
#f35:hover
{
    background-color:green;
    padding-left: 17px;
    padding-right: 17px;
    padding-top: 7px;
    padding-bottom: 7px;
}
    
    </style>
</head>

<body>
       <?php include 'header3.php'; ?>
       <?php include 'nody.php'; ?>
       <?php include 'footer3.php'; ?>

</body>
</html>