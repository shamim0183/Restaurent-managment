<?php require_once('config2.php'); ?>



<!DOCTYPE html>
<html>
  <head>
    <title>BBR | Delivery Man Login </title>
    <link rel="icon" type="image/ico" href="../images/logo1.png" />

    <link rel="stylesheet" href="../styles/forget.css">
    <link href="https://fonts.googleapis.com/css2?family=Crimson+Text:ital@1&display=swap" rel="stylesheet">

    </head>
    <body>
        <p>Delivery Man Forgot Password Here</p>
<div class="login-form">
<input type="radio" name="tab" class="tab" id="sign-up-tab" checked>
<label for="sign-up-tab" class="tab-header" id="tab-header1">Forgot Password</label>

    <form id="form1" action="forgetpassword2.php" method="POST">
    <div class="header">Recover Password Here</div>
   
    
  
    <div class="form-input">
        <label class="label1">E-mail Address :</label>
        <input type ="mail" class="input1" id="new-email" placeholder="Enter E-mail Address" name="email" oninvalid="InvalidMsg1(this);"  oninput="InvalidMsg1(this);" required>
    </div>
    
    
    
        <div>
        <input type ="submit" id="sign-up" class="submit-button" name="submit"value="Send Password Email">
        <a  href="login2.php" style ="width:50px;height:10px;color:black;font-size:25px;text-decoration:none">Cancel?</a>

    </div>
</form>
</div>
<script> 
               
        function InvalidMsg1(textbox) { 
         

            if (textbox.value === '') { 
                textbox.setCustomValidity ('Please Enter Email Address'); 
            } else if (textbox.validity.typeMismatch) { 
                textbox.setCustomValidity ('Please enter an email address which is valid!'); 
            } else { 
               k1 =textbox.value;
                textbox.setCustomValidity(''); 
            } 
  
            return true; 
        
    } 
   
   
  
  
  
    </script> 
</body>
</html>