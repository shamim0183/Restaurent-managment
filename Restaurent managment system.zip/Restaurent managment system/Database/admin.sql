-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2020 at 05:59 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `admin`
--

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_name` varchar(255) NOT NULL,
  `food_code` varchar(255) NOT NULL,
  `food_price` double NOT NULL,
  `catagory` varchar(200) NOT NULL,
  `price_tax` double NOT NULL,
  `food_image` varchar(255) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_name`, `food_code`, `food_price`, `catagory`, `price_tax`, `food_image`, `id`) VALUES
('Vegetable_Cheese_Sandwich', '4', 98, 'Morning', 2, 'Vegetable_Cheese_Sandwich.jpg', 4),
('Chicken_Cheese_Sandwich', '5', 99, 'Morning', 2, 'Chicken_Cheese_Sandwich.jpg', 5),
('Chicken_Sandwich', '6', 99, 'Morning', 2, 'Chicken_Sandwich.jpg', 6),
('Egg_Sandwich', '7', 99, 'Morning', 2, 'Egg_Sandwich.jpg', 7),
('Club_Sandwich', '8', 99, 'Morning', 2, 'Club_Sandwich.jpg', 8),
('Chicken_Cutlet', '9', 99, 'Lunch,Diner', 2, 'Chicken_Cutlet.jpg', 9),
('Vegetable_Cutlet', '10', 99, 'Lunch,Diner', 2, 'Vegetable_Cutlet.jpg', 10),
('Fish_Cutlet', '11', 99, 'Lunch,Diner', 2, 'Fish_Cutlet.jpg', 11),
('Chicken_With_Bread_Ball', '12', 99, 'Lunch,Diner', 2, 'Chicken_With_Bread_Ball.jpg', 12),
('Hot_dog', '13', 99, 'Lunch,Diner', 2, 'Hot_dog.jpg', 13),
('Fried_chicken', '14', 400, 'Lunch,Diner', 2, 'Fried_chicken.jpg', 14),
('Donuts', '15', 99, 'Lunch,Diner', 2, 'Donuts.jpg', 15),
('Baguette', '16', 99, 'Lunch,Diner', 2, 'Baguette.jpg\r\n', 16),
('Pizza', '17', 99, 'Morning', 2, 'Pizza.jpg', 17),
('Sausage', '18', 99, 'Lunch,Diner', 2, 'Sausage.jpg', 18),
('Noodle', '19', 99, 'Lunch,Diner', 2, 'Noodle.jpg', 19),
('Chip_Fry', '20', 99, 'Lunch,Diner', 2, 'Chip_Fry.jpg', 20),
('Burrito', '21', 99, 'Lunch,Diner', 2, 'Burrito.jpg', 21),
('Muffin', '22', 99, 'Lunch,Diner', 2, 'Muffin.jpg', 22),
('Soft_drink', '23', 30, 'Lunch,Diner', 2, 'Soft_drink.jpg', 23),
('Tomato_Juice', '24', 30, 'Lunch,Diner', 2, 'Tomato_Juice.jpg', 24),
('Smoothie', '25', 50, 'Lunch,Diner', 2, 'Smoothie.jpg', 25),
('Milkshake', '26', 60, 'Lunch,Diner', 2, 'Milkshake.jpg', 26),
('Coconut_Milk', '27', 70, 'Lunch,Diner', 2, 'Coconut_Milk.jpg', 27),
('Orange_Juice', '28', 40, 'Lunch,Diner', 2, 'Orange_Juice.jpg', 28),
('Lemonade', '29', 40, 'Lunch,Diner', 2, 'Lemonade.jpg', 29),
('Water', '30', 15, 'Lunch,Diner', 2, 'Water.jpg', 30),
('Coffee', '31', 60, 'Lunch,Diner', 2, 'Coffee.jpg', 31),
('Tea', '32', 20, 'Lunch,Diner', 2, 'Tea.jpg', 32),
('Green_Tea', '33', 25, 'Lunch,Diner', 2, 'Green_Tea.jpg', 33),
('Chocolate_Milk', '34', 90, 'Lunch,Diner', 2, 'Chocolate_Milk.jpg', 34),
('Hot_Chocolate', '35', 100, 'Lunch,Diner', 2, 'Hot_Chocolate.jpg', 35),
('Parata', '36', 10, 'Lunch,Diner', 2, 'Parata.jpg', 36),
('Alu_Parata', '37', 25, 'Lunch,Diner', 2, 'Alu_Parata.jpg', 37),
('Chicken_Parata', '38', 55, 'Lunch,Diner', 2, 'Chicken_Parata.jpg', 38),
('Chapati', '39', 25, 'Lunch,Diner', 2, 'Chapati.jpg', 39),
('Nan', '40', 30, 'Lunch,Diner', 2, 'Nan.jpg', 40),
('Butter / Garlic Nan', '41', 35, 'Lunch,Diner', 2, 'Butter_Garlic_Nan.jpg', 41),
('Bosnian Rooti', '42', 30, 'Lunch,Diner', 2, 'Bosnian_Rooti.jpg', 42),
('Toast', '43', 30, 'Lunch,Diner', 2, 'Toast.jpg', 43),
('Toast Butter Jam', '44', 20, 'Lunch,Diner', 2, 'Toast_Butter_Jam.jpg', 44),
('Scramble Egg Toast', '45', 20, 'Lunch,Diner', 2, 'Scramble_Egg_Toast.jpg', 45),
('Pan Cake with Lemon & Honey', '46', 30, 'Lunch,Diner', 2, 'Pan_Cake_with_Lemon_Honey.jpg', 46),
('Corn Flakes Milk & Sugar', '47', 15, 'Lunch,Diner', 2, 'Corn_Flakes_Milk_Sugar.jpg', 47),
('Vegetable Bhajee', '48', 15, 'Lunch,Diner', 2, 'Vegetable_Bhajee.jpg', 48),
('Alu Bhajee', '49', 15, 'Lunch,Diner', 2, 'Alu_Bhajee.jpg', 49),
('Begun Bhajee', '50', 15, 'Lunch,Diner', 2, 'Begun_Bhajee.jpg', 50),
('Two Eggs in any Style', '51', 30, 'Lunch,Diner', 2, 'Two_Eggs_in_any_Style.jpg', 51),
('Chicken Bhoona / Mashalla / Curry', '52', 150, 'Lunch,Diner', 2, 'Chicken_Bhoona_Mashalla_Curry.jpg', 52),
('Mutton Curry / Bhoona / Mashalla', '53', 250, 'Lunch,Diner', 2, 'Mutton_Curry_Bhoona_Mashalla.jpg', 53),
('Beef Bhoona / Mashalla / Curry', '54', 200, 'Lunch,Diner', 2, 'Beef_Bhoona_Mashalla_Curry.jpg', 54),
('Plain Rice', '55', 40, 'Lunch,Diner', 2, 'Plain_Rice.jpg', 55),
('Plain Polaue', '56', 50, 'Lunch,Diner', 2, 'Plain_Polaue.jpg', 56),
('Vegetable Polaue', '57', 60, 'Lunch,Diner', 2, 'Vegetable_Polaue.jpg', 57),
('Alu Bharta', '58', 15, 'Lunch,Diner', 2, 'Alu_Bharta.jpg', 58),
('Alu With Egg Bharta', '59', 20, 'Lunch,Diner', 2, 'Alu_With_Egg_Bharta.jpg', 59),
('Kala Bharta', '60', 20, 'Lunch,Diner', 2, 'Kala_Bharta.jpg', 60),
('Chingri Bharta', '61', 30, 'Lunch,Diner', 2, 'Chingri_Bharta.jpg', 61),
('Dal Bharta', '62', 15, 'Lunch,Diner', 2, 'Dal_Bharta.jpg', 62),
('Begun Bharta', '63', 15, 'Lunch,Diner', 2, 'Begun_Bharta.jpg', 63),
('Papaya Bharta', '64', 10, 'Lunch,Diner', 2, 'Papaya_Bharta.jpg', 64),
('Dal', '65', 30, 'Lunch,Diner', 2, 'Dal.jpg', 65),
('Mixed Green Salad', '66', 40, 'Lunch,Diner', 2, 'Mixed_Green_Salad.jpg', 66),
('Raitha Salad', '67', 70, 'Lunch,Diner', 2, 'Raitha_Salad.jpg', 67),
('Salad With Yogurt', '68', 100, 'Lunch,Diner', 2, 'Salad_With_Yogurt.jpg', 68),
('Salad With Poneer', '69', 120, 'Lunch,Diner', 2, 'Salad_With_Poneer.jpg', 69),
('Thai Chicken Salad', '70', 200, 'Lunch,Diner', 2, 'Thai_Chicken_Salad.jpg', 70),
('Mutton Dal', '71', 120, 'Lunch,Diner', 2, 'Mutton_Dal.jpg', 71),
('Mutton_Curry_/_Bhoona', '72', 150, 'Lunch,Diner', 2, 'Mutton_Curry_Bhoona.jpg', 72),
('Beef_Curry_/_Bhoona', '73', 140, 'Lunch,Diner', 2, 'Beef_Curry_Bhoona.jpg', 73);

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `food_name` varchar(200) NOT NULL,
  `Customer_Name` varchar(200) NOT NULL,
  `Customer_Id` varchar(200) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  `id` int(11) NOT NULL,
  `Image` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `price_tax` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`food_name`, `Customer_Name`, `Customer_Id`, `quantity`, `price`, `total`, `id`, `Image`, `status`, `price_tax`) VALUES
('Vegetable_Cheese_Sandwich', 'rakib', '123', 1, 98, 98, 1, 'Vegetable_Cheese_Sandwich.jpg', 'processing', 2);

-- --------------------------------------------------------

--
-- Table structure for table `registe1`
--

CREATE TABLE `registe1` (
  `username` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `Customer_Id` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registe1`
--

INSERT INTO `registe1` (`username`, `passwordd`, `Customer_Id`, `id`) VALUES
('rakib', '1234567', '123', 4),
('rakib', '1234567', '123', 5),
('rakib', '1234567', '123', 6),
('rakib', '1234567', '123', 7),
('rakib', '1234567', '123', 8),
('rakib', '1234567', '123', 9),
('rakib', '1234567', '123', 10),
('rakib', '1234567', '123', 11),
('rakib', '1234567', '123', 12);

-- --------------------------------------------------------

--
-- Table structure for table `registe2`
--

CREATE TABLE `registe2` (
  `username` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registe2`
--

INSERT INTO `registe2` (`username`, `passwordd`, `id`) VALUES
('rakibr', '12345678', 1),
('rakibr', '12345678', 2),
('rakib3', '1234567', 3);

-- --------------------------------------------------------

--
-- Table structure for table `registe3`
--

CREATE TABLE `registe3` (
  `username` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `delivery_man_id` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `registe4`
--

CREATE TABLE `registe4` (
  `username` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `waiterid` int(11) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `username` varchar(200) NOT NULL,
  `Customer_Id` varchar(200) NOT NULL,
  `Customer_Address` varchar(200) NOT NULL,
  `Company_Name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `Mobile_Number` varchar(200) NOT NULL,
  `tab` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`username`, `Customer_Id`, `Customer_Address`, `Company_Name`, `email`, `Mobile_Number`, `tab`, `passwordd`, `id`) VALUES
('rakib', '123', 'sss', 'ssss', 'meheraddhaka2015@gmail.com', '01884612917', 'Male', '1234567', 1);

-- --------------------------------------------------------

--
-- Table structure for table `register1`
--

CREATE TABLE `register1` (
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `tab` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register1`
--

INSERT INTO `register1` (`username`, `email`, `tab`, `passwordd`, `id`) VALUES
('rakibr', 'salamkhan9t7a@gmail.com', 'Male', '12345678', 1),
('tutul', 'tutulhossain.cse@gmail.com', 'Male', '12345678', 2),
('rakib3', 't@gmail.com', 'Male', '1234567', 3);

-- --------------------------------------------------------

--
-- Table structure for table `register2`
--

CREATE TABLE `register2` (
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `delivery_man_id` varchar(200) NOT NULL,
  `delivery_area` varchar(200) NOT NULL,
  `tab` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register2`
--

INSERT INTO `register2` (`username`, `email`, `delivery_man_id`, `delivery_area`, `tab`, `passwordd`, `id`) VALUES
('rakib', 'meheraddhaka2015@gmail.com', '123', 'west', 'Male', '1234567', 3);

-- --------------------------------------------------------

--
-- Table structure for table `register3`
--

CREATE TABLE `register3` (
  `username` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `waiterid` varchar(200) NOT NULL,
  `waitertable` int(11) NOT NULL,
  `tab` varchar(200) NOT NULL,
  `passwordd` varchar(200) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register3`
--

INSERT INTO `register3` (`username`, `email`, `waiterid`, `waitertable`, `tab`, `passwordd`, `id`) VALUES
('rakib', 'meheraddhaka2015@gmail.com', '123', 12, 'Male', '1234567', 1);

-- --------------------------------------------------------

--
-- Table structure for table `wish`
--

CREATE TABLE `wish` (
  `id` int(11) NOT NULL,
  `Customer_Name` varchar(200) NOT NULL,
  `Customer_Id` int(11) NOT NULL,
  `Customer_Email` varchar(200) NOT NULL,
  `Wish_Food_Name` varchar(200) NOT NULL,
  `Food_Code_No` varchar(200) NOT NULL,
  `Table_Number` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wish`
--

INSERT INTO `wish` (`id`, `Customer_Name`, `Customer_Id`, `Customer_Email`, `Wish_Food_Name`, `Food_Code_No`, `Table_Number`, `status`) VALUES
(1, 'rakib', 123, 'meherdhaka2015@gmail.com', 'Vegetable_Cheese_Sandwich', '4', '12', 'processing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `food` ADD FULLTEXT KEY `food_name` (`food_name`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registe1`
--
ALTER TABLE `registe1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registe2`
--
ALTER TABLE `registe2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registe3`
--
ALTER TABLE `registe3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registe4`
--
ALTER TABLE `registe4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register1`
--
ALTER TABLE `register1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register2`
--
ALTER TABLE `register2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register3`
--
ALTER TABLE `register3`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wish`
--
ALTER TABLE `wish`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `registe1`
--
ALTER TABLE `registe1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `registe2`
--
ALTER TABLE `registe2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registe3`
--
ALTER TABLE `registe3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `registe4`
--
ALTER TABLE `registe4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `register1`
--
ALTER TABLE `register1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `register2`
--
ALTER TABLE `register2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `register3`
--
ALTER TABLE `register3`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `wish`
--
ALTER TABLE `wish`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
