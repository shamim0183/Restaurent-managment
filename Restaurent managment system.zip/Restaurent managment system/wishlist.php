<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BBR | Wish List</title>
    <link rel="icon" type="image/ico" href="images/logo1.png" />
    <style>
    
    #f15
{
    background-color:black;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 7px;
    padding-bottom: 7px;

}
#f15:hover
{
    background-color:green;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 7px;
    padding-bottom: 7px;
}
    
    </style>
</head>

<body>
       <?php include 'header.php'; ?>
       <?php include 'body5.php'; ?>
       <?php include 'footer.php'; ?>

</body>
</html>